export const siteConfig = {
  name: "Saasfly",
  description: "We provide an easier way to build saas service in production",
  url: "https://github.com/saasfly/saasfly",
  ogImage: "",
  links: {
    github: "https://github.com/saasfly/saasfly",
  },
};
