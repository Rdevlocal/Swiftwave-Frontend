export interface Meteor {
  name: string;
  description: string;
  button_content: string;
  url: string;
}
