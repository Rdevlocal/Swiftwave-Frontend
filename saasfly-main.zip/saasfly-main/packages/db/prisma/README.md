#NOTE

##FAQ
if you found can't generate prisma types, please use bun i -g prisma-kysely
